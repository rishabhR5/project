<?php
    $dbServername = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbName = "placement";
    $conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

?>
