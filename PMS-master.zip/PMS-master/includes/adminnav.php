<?php session_start(); ?>
<html>
<body>

    <img id="logo" src="../images/logo.png" width="40px">
    <nav>
      <ul>
        <a href="#" id="admin"><li>Companies</li></a>
        <a href="#" id="student"><li>Students</li></a>
        <a href="#" class="active" id="home"><li>Admin</li></a>
        <a href="#" class="btn" id="btn">Logout</a>
      </ul>
    </nav>
	</body>
</html>