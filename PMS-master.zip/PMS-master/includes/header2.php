<html>
<body>
    <?php session_start(); ?>
    <img id="logo" src="../images/logo.png" width="40px">
    <nav>
      <ul class="navul">
        <a href="../index.php" class="active" id="home"><li>Home</li></a>
        <a href="../admin/login.php" id="admin"><li>Admin</li></a>
        <a href="../student/login.php" id="student"><li>Student</li></a>
        <a href="#" class="btn" id="btn">SIGNUP</a>
      </ul>
    </nav>
	</body>
</html>